package main

import (
	"fmt"
	"os"

	"eldoria/interne/ui"
)

func main() {
	// tcell a besoin d'une variable TERM valide pour connaître
	// les capacités du terminal. Certains environnements (IDE,
	// lancement d'un binaire directement, etc.) ne la fournissent pas.
	term := os.Getenv("TERM")
	if term == "" || term == "dumb" {
		_ = os.Setenv("TERM", "xterm-256color")
	}

	app := ui.NewApp()

	if err := app.Run(); err != nil {
		fmt.Fprintln(os.Stderr, "Erreur TUI :", err)
		os.Exit(1)
	}
}
