package ui

import (
	"time"

	"eldoria/interne/models"

	"github.com/gdamore/tcell/v2"
	"github.com/rivo/tview"
)

func (app *App) createMainMenu() *tview.Flex {
	title := tview.NewTextView()
	title.SetText(eldoriaLogo)
	title.SetTextAlign(tview.AlignCenter)
	title.SetTextColor(ColorPrimary)
	title.SetBackgroundTransparent(true)

	subtitle := tview.NewTextView()
	subtitle.SetText("LES FRAGMENTS DU SOUVENIR")
	subtitle.SetTextAlign(tview.AlignCenter)
	subtitle.SetTextColor(ColorSecondary)
	subtitle.SetBackgroundTransparent(true)

	app.mainMenu = app.createMenuList()

	center := tview.NewFlex()
	center.SetDirection(tview.FlexRow)
	center.SetBackgroundTransparent(true)
	center.AddItem(nil, 0, 1, false)
	center.AddItem(title, 8, 0, false)
	center.AddItem(subtitle, 2, 0, false)
	center.AddItem(nil, 2, 0, false)
	center.AddItem(app.mainMenu, 9, 0, true)
	center.AddItem(nil, 0, 1, false)

	root := tview.NewFlex()
	root.SetBackgroundTransparent(true)
	root.AddItem(nil, 0, 1, false)
	root.AddItem(center, 54, 0, true)
	root.AddItem(nil, 0, 1, false)

	return root
}

func (app *App) createMenuList() *tview.List {
	menu := tview.NewList()
	menu.ShowSecondaryText(false)
	menu.SetHighlightFullLine(true)
	menu.SetSelectedFocusOnly(true)

	menu.SetMainTextColor(ColorText)
	menu.SetSelectedTextColor(tcell.ColorWhite)
	menu.SetSelectedBackgroundColor(ColorSelected)
	menu.SetBackgroundColor(ColorPanel)
	menu.SetBorder(true)
	menu.SetBorderColor(ColorBorder)
	menu.SetBorderAttributes(tcell.AttrBold)
	menu.SetTitle(" MENU PRINCIPAL ")
	menu.SetTitleColor(ColorPrimary)
	menu.SetTitleAlign(tview.AlignCenter)
	menu.SetBorderPadding(1, 1, 2, 2)

	menu.AddItem("▶  JOUER", "", 'J', func() {
		app.startGame()
	})
	menu.AddItem("   OPTIONS", "", 'O', func() {
		app.openOptions(false)
	})
	menu.AddItem("   QUITTER", "", 'Q', func() {
		app.stop()
	})

	return menu
}

func (app *App) startGame() {
	app.InGame = true
	app.show(models.SceneExploration)
}

func (app *App) createGamePlaceholder() *tview.Flex {
	title := tview.NewTextView()
	title.SetText("ELDORIA")
	title.SetTextAlign(tview.AlignCenter)
	title.SetTextColor(ColorPrimary)
	title.SetTextStyle(tcell.StyleDefault.Bold(true))
	title.SetBackgroundColor(ColorBackground)

	body := tview.NewTextView()
	body.SetText(
		"\n\n" +
			"FRONTEND INITIALISÉ\n\n" +
			"La prochaine étape sera de connecter\n" +
			"la création de personnage au backend existant.\n\n" +
			"ESC  →  PAUSE",
	)
	body.SetTextAlign(tview.AlignCenter)
	body.SetTextColor(ColorText)
	body.SetBackgroundColor(ColorBackground)
	body.SetBorder(true)
	body.SetBorderColor(ColorBorder)
	body.SetTitle(" EXPLORATION ")
	body.SetTitleColor(ColorSecondary)

	root := tview.NewFlex().SetDirection(tview.FlexRow)
	root.SetBackgroundColor(ColorBackground)
	root.AddItem(nil, 0, 1, false)
	root.AddItem(title, 3, 0, false)
	root.AddItem(body, 13, 0, false)
	root.AddItem(nil, 0, 1, false)

	return root
}

func NewASCIIBackground(app *App) *tview.TextView {
	video, err := NewASCIIVideo(
		app.Application,
		"assets/ascii/intro",
		120*time.Millisecond,
	)

	if err != nil || len(video.frames) == 0 {
		background := tview.NewTextView()
		background.SetBackgroundColor(ColorBackground)
		return background
	}

	app.asciiVideo = video
	video.Start()

	return video.View()
}

const eldoriaLogo = `
███████╗██╗     ██████╗  ██████╗ ██████╗ ██╗ █████╗
██╔════╝██║     ██╔══██╗██╔═══██╗██╔══██╗██║██╔══██╗
█████╗  ██║     ██║  ██║██║   ██║██████╔╝██║███████║
██╔══╝  ██║     ██║  ██║██║   ██║██╔══██╗██║██╔══██║
███████╗███████╗██████╔╝╚██████╔╝██║  ██║██║██║  ██║
╚══════╝╚══════╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝╚═╝  ╚═╝`
