package ui

import (
	"fmt"

	"github.com/gdamore/tcell/v2"
	"github.com/rivo/tview"
)

func (app *App) createOptions() *tview.Flex {
	title := tview.NewTextView()
	title.SetText("OPTIONS")
	title.SetTextAlign(tview.AlignCenter)
	title.SetTextColor(ColorPrimary)
	title.SetTextStyle(tcell.StyleDefault.Bold(true))
	title.SetBackgroundColor(ColorBackground)

	app.volumeView = tview.NewTextView()
	app.volumeView.SetTextAlign(tview.AlignCenter)
	app.volumeView.SetTextColor(ColorText)
	app.volumeView.SetBackgroundColor(ColorBackground)
	app.volumeView.SetBorder(true)
	app.volumeView.SetBorderColor(ColorBorder)
	app.volumeView.SetTitle(" AUDIO ")
	app.volumeView.SetTitleColor(ColorSecondary)
	app.volumeView.SetBorderPadding(1, 1, 2, 2)
	app.volumeView.SetInputCapture(func(event *tcell.EventKey) *tcell.EventKey {
		switch event.Key() {
		case tcell.KeyLeft:
			app.changeVolume(-10)
			updateVolumeText(app.volumeView, app.Volume)
			return nil
		case tcell.KeyRight:
			app.changeVolume(10)
			updateVolumeText(app.volumeView, app.Volume)
			return nil
		case tcell.KeyHome:
			app.Volume = 0
			updateVolumeText(app.volumeView, app.Volume)
			return nil
		case tcell.KeyEnd:
			app.Volume = 100
			updateVolumeText(app.volumeView, app.Volume)
			return nil
		}
		return event
	})
	updateVolumeText(app.volumeView, app.Volume)

	hint := tview.NewTextView()
	hint.SetText("← / → modifier    HOME / END régler    ESC retour")
	hint.SetTextAlign(tview.AlignCenter)
	hint.SetTextColor(ColorMuted)
	hint.SetBackgroundColor(ColorBackground)

	content := tview.NewFlex().SetDirection(tview.FlexRow)
	content.SetBackgroundColor(ColorBackground)
	content.AddItem(nil, 0, 1, false)
	content.AddItem(title, 3, 0, false)
	content.AddItem(nil, 1, 0, false)
	content.AddItem(app.volumeView, 7, 0, true)
	content.AddItem(hint, 2, 0, false)
	content.AddItem(nil, 0, 1, false)

	return content
}

func (app *App) changeVolume(delta int) {
	app.Volume += delta

	if app.Volume < 0 {
		app.Volume = 0
	}
	if app.Volume > 100 {
		app.Volume = 100
	}
}

func updateVolumeText(view *tview.TextView, volume int) {
	view.SetText(fmt.Sprintf(
		"MUSIQUE\n\n%s %d%%",
		volumeBar(volume, 20),
		volume,
	))
}

func volumeBar(volume, width int) string {
	filled := volume * width / 100
	return repeatRune('█', filled) + repeatRune('░', width-filled)
}

func repeatRune(r rune, count int) string {
	if count <= 0 {
		return ""
	}

	result := make([]rune, count)
	for i := range result {
		result[i] = r
	}
	return string(result)
}

func (app *App) openOptions(fromPause bool) {
	if fromPause {
		app.InGame = true
	}

	app.show(pageOptions)
}
