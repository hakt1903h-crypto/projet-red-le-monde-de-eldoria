package ui

import "github.com/gdamore/tcell/v2"

var (
	ColorBackground = tcell.NewRGBColor(5, 8, 18)
	ColorOverlay    = tcell.NewRGBColor(8, 7, 18)
	ColorPanel      = tcell.NewRGBColor(13, 10, 28)
	ColorPrimary    = tcell.NewRGBColor(190, 150, 255)
	ColorSecondary  = tcell.NewRGBColor(110, 170, 255)
	ColorText       = tcell.NewRGBColor(235, 235, 245)
	ColorMuted      = tcell.NewRGBColor(125, 128, 155)
	ColorSelected   = tcell.NewRGBColor(105, 55, 170)
	ColorBorder     = tcell.NewRGBColor(120, 90, 190)
)
