package ui

import (
	"github.com/gdamore/tcell/v2"
	"github.com/rivo/tview"
)

func (app *App) createPause() *tview.Flex {
	title := tview.NewTextView()
	title.SetText("PAUSE")
	title.SetTextAlign(tview.AlignCenter)
	title.SetTextColor(ColorPrimary)
	title.SetBackgroundColor(ColorOverlay)
	title.SetTextStyle(tcell.StyleDefault.Bold(true))

	app.pauseMenu = tview.NewList()
	app.pauseMenu.ShowSecondaryText(false)
	app.pauseMenu.SetHighlightFullLine(true)
	app.pauseMenu.SetSelectedFocusOnly(true)
	app.pauseMenu.SetMainTextColor(ColorText)
	app.pauseMenu.SetSelectedTextColor(tcell.ColorWhite)
	app.pauseMenu.SetSelectedBackgroundColor(ColorSelected)
	app.pauseMenu.SetBackgroundColor(ColorPanel)
	app.pauseMenu.SetBorder(true)
	app.pauseMenu.SetBorderColor(ColorBorder)
	app.pauseMenu.SetTitle(" PAUSE ")
	app.pauseMenu.SetTitleColor(ColorPrimary)
	app.pauseMenu.SetTitleAlign(tview.AlignCenter)
	app.pauseMenu.SetBorderPadding(1, 1, 2, 2)

	app.pauseMenu.AddItem("▶  REPRENDRE", "", 'R', func() {
		app.resumeGame()
	})
	app.pauseMenu.AddItem("   OPTIONS", "", 'O', func() {
		app.openOptions(true)
	})
	app.pauseMenu.AddItem("   SAUVEGARDER", "", 'S', func() {
		app.pauseStatus.SetText("Sauvegarde : système à venir après le frontend de base.")
	})
	app.pauseMenu.AddItem("   QUITTER VERS LE MENU", "", 'Q', func() {
		app.quitToMenu()
	})

	app.pauseStatus = tview.NewTextView()
	app.pauseStatus.SetTextAlign(tview.AlignCenter)
	app.pauseStatus.SetTextColor(ColorMuted)
	app.pauseStatus.SetBackgroundColor(ColorOverlay)

	root := tview.NewFlex().SetDirection(tview.FlexRow)
	root.SetBackgroundColor(ColorOverlay)
	root.AddItem(nil, 0, 1, false)
	root.AddItem(title, 3, 0, false)
	root.AddItem(app.pauseMenu, 12, 0, true)
	root.AddItem(app.pauseStatus, 2, 0, false)
	root.AddItem(nil, 0, 1, false)

	return root
}
