package ui

import (
	"github.com/gdamore/tcell/v2"
	"github.com/rivo/tview"

	"eldoria/interne/models"
)

const pageOptions = "OPTIONS"

type App struct {
	Application *tview.Application
	Pages       *tview.Pages

	CurrentPage  string
	PreviousPage string
	Volume       int
	InGame       bool

	mainMenu    *tview.List
	pauseMenu   *tview.List
	volumeView  *tview.TextView
	pauseStatus *tview.TextView
	asciiVideo  *ASCIIVideo
}

func NewApp() *App {
	app := &App{
		Application: tview.NewApplication(),
		Pages:       tview.NewPages(),
		Volume:      70,
	}

	app.Application.SetInputCapture(app.globalInput)
	app.buildPages()
	app.focusCurrentPage()

	return app
}

func (app *App) Run() error {
	app.Application.SetRoot(app.Pages, true)
	return app.Application.Run()
}

func (app *App) buildPages() {
	background := NewASCIIBackground(app)

	app.Pages.AddPage("background", background, true, true)
	app.Pages.AddPage(models.SceneMainMenu, app.createMainMenu(), true, true)
	app.Pages.AddPage(pageOptions, app.createOptions(), true, false)
	app.Pages.AddPage(models.ScenePause, app.createPause(), true, false)
	app.Pages.AddPage(models.SceneExploration, app.createGamePlaceholder(), true, false)

	app.CurrentPage = models.SceneMainMenu
}

func (app *App) show(page string) {
	if app.CurrentPage == page {
		app.focusCurrentPage()
		return
	}

	app.Pages.HidePage(app.CurrentPage)
	app.Pages.ShowPage(page)
	app.PreviousPage = app.CurrentPage
	app.CurrentPage = page
	app.focusCurrentPage()
	app.Application.Draw()
}

func (app *App) showMainMenu() {
	app.InGame = false

	if app.CurrentPage == models.SceneMainMenu {
		app.focusCurrentPage()
		return
	}
	app.Pages.HidePage(app.CurrentPage)
	app.Pages.ShowPage(models.SceneMainMenu)
	app.CurrentPage = models.SceneMainMenu
	app.PreviousPage = ""
	app.focusCurrentPage()
}

func (app *App) focusCurrentPage() {
	switch app.CurrentPage {
	case models.SceneMainMenu:
		app.Application.SetFocus(app.mainMenu)
	case pageOptions:
		app.Application.SetFocus(app.volumeView)
	case models.ScenePause:
		app.Application.SetFocus(app.pauseMenu)
	case models.SceneExploration:
		// The exploration view is not interactive yet.
	}
}

func (app *App) globalInput(event *tcell.EventKey) *tcell.EventKey {
	if event.Key() != tcell.KeyEscape {
		return event
	}

	switch app.CurrentPage {
	case models.SceneMainMenu:
		return event
	case pageOptions:
		if app.InGame {
			app.show(models.ScenePause)
		} else {
			app.showMainMenu()
		}
		return nil
	case models.ScenePause:
		app.resumeGame()
		return nil
	case models.SceneExploration:
		app.showPause()
		return nil
	default:
		return nil
	}
}

func (app *App) showPause() {
	if !app.InGame {
		return
	}

	app.show(models.ScenePause)
}

func (app *App) resumeGame() {
	if !app.InGame {
		app.showMainMenu()
		return
	}

	app.Pages.HidePage(app.CurrentPage)
	app.Pages.ShowPage(models.SceneExploration)
	app.CurrentPage = models.SceneExploration
	app.PreviousPage = ""
	app.focusCurrentPage()
}

func (app *App) quitToMenu() {
	app.showMainMenu()
}

func (app *App) stop() {
	if app.asciiVideo != nil {
		app.asciiVideo.Stop()
	}

	app.Application.Stop()
}
