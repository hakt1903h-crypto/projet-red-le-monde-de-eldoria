package ui

import (
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"github.com/rivo/tview"
)

type ASCIIVideo struct {
	frames   []string
	view     *tview.TextView
	app      *tview.Application
	interval time.Duration
	stop     chan struct{}
}

func NewASCIIVideo(
	app *tview.Application,
	path string,
	interval time.Duration,
) (*ASCIIVideo, error) {
	resolved := resolveAssetPath(path)
	files, err := filepath.Glob(filepath.Join(resolved, "*.txt"))
	if err != nil {
		return nil, err
	}

	sort.Strings(files)

	frames := make([]string, 0, len(files))
	for _, file := range files {
		data, err := os.ReadFile(file)
		if err != nil {
			return nil, err
		}

		frames = append(frames, strings.TrimRight(string(data), "\n"))
	}

	view := tview.NewTextView()
	view.SetTextAlign(tview.AlignCenter)
	view.SetScrollable(false)
	view.SetWrap(false)
	view.SetTextColor(ColorSecondary)
	view.SetBackgroundColor(ColorBackground)

	if len(frames) > 0 {
		view.SetText(frames[0])
	}

	return &ASCIIVideo{
		frames:   frames,
		view:     view,
		app:      app,
		interval: interval,
		stop:     make(chan struct{}),
	}, nil
}

func (video *ASCIIVideo) View() *tview.TextView {
	return video.view
}

func (video *ASCIIVideo) Start() {
	if len(video.frames) <= 1 {
		return
	}

	go func() {
		ticker := time.NewTicker(video.interval)
		defer ticker.Stop()

		index := 1

		for {
			select {
			case <-video.stop:
				return
			case <-ticker.C:
			}

			frame := video.frames[index]

			video.app.QueueUpdateDraw(func() {
				video.view.SetText(frame)
			})

			index++
			if index >= len(video.frames) {
				index = 0
			}
		}
	}()
}

func (video *ASCIIVideo) Stop() {
	select {
	case <-video.stop:
		return
	default:
		close(video.stop)
	}
}

func resolveAssetPath(path string) string {
	candidates := []string{
		path,
		filepath.Join("src", path),
		filepath.Join("..", path),
	}

	for _, candidate := range candidates {
		if info, err := os.Stat(candidate); err == nil && info.IsDir() {
			return candidate
		}
	}

	return path
}
